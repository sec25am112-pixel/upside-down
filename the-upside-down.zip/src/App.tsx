import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Login } from './components/Login.tsx';
import { Sender } from './components/Sender.tsx';
import { Receiver } from './components/Receiver.tsx';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/sender" element={<Sender />} />
        <Route path="/receiver" element={<Receiver />} />
      </Routes>
    </Router>
  );
}

