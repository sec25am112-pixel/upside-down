import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, User } from '../firebase.ts';
import { Layout } from './Layout.tsx';

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  if (loading) return <Layout><div className="text-2xl animate-pulse">LOADING...</div></Layout>;

  return (
    <Layout>
      <div className="flex flex-col items-center gap-8 max-w-md w-full p-12 wood-panel rounded-xl shadow-2xl">
        <h2 className="text-4xl text-blood-red flicker">CHOOSE YOUR PATH</h2>
        
        {!user ? (
          <button 
            onClick={handleLogin}
            className="w-full py-4 px-8 bg-blood-red text-white text-2xl font-bold rounded-lg hover:bg-red-800 transition-colors shadow-[0_0_15px_rgba(255,34,0,0.5)] border-2 border-red-900"
            style={{ fontFamily: 'Special Elite' }}
          >
            ENTER THE VOID (LOGIN)
          </button>
        ) : (
          <div className="flex flex-col gap-4 w-full">
            <p className="text-center text-xl mb-4">WELCOME, {user.displayName?.toUpperCase()}</p>
            <button 
              onClick={() => navigate('/sender')}
              className="w-full py-4 px-8 bg-gray-800 text-white text-xl font-bold rounded-lg hover:bg-gray-700 transition-colors border-2 border-gray-600"
              style={{ fontFamily: 'Special Elite' }}
            >
              BECOME THE SENDER
            </button>
            <button 
              onClick={() => navigate('/receiver')}
              className="w-full py-4 px-8 bg-gray-800 text-white text-xl font-bold rounded-lg hover:bg-gray-700 transition-colors border-2 border-gray-600"
              style={{ fontFamily: 'Special Elite' }}
            >
              BECOME THE RECEIVER
            </button>
            <button 
              onClick={() => auth.signOut()}
              className="mt-8 text-blood-red hover:underline"
            >
              LEAVE THIS PLACE
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
};
