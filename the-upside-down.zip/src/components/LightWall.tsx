import React from 'react';
import { Bulb } from './Bulb.tsx';

interface LightWallProps {
  activeLetter: string | null;
}

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export const LightWall: React.FC<LightWallProps> = ({ activeLetter }) => {
  return (
    <div className="relative w-full max-w-4xl mx-auto p-8 rounded-lg wood-panel">
      {/* Decorative Wires */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40">
        <path 
          d="M 50 100 Q 200 80 400 100 T 800 100" 
          fill="none" 
          stroke="#000" 
          strokeWidth="2" 
        />
        <path 
          d="M 50 250 Q 200 230 400 250 T 800 250" 
          fill="none" 
          stroke="#000" 
          strokeWidth="2" 
        />
        <path 
          d="M 50 400 Q 200 380 400 400 T 800 400" 
          fill="none" 
          stroke="#000" 
          strokeWidth="2" 
        />
      </svg>

      <div className="grid grid-cols-9 gap-4 relative z-10">
        {/* Row 1: A-I */}
        {ALPHABET.slice(0, 9).map((letter) => (
          <Bulb 
            key={letter} 
            letter={letter} 
            isActive={activeLetter === letter} 
          />
        ))}

        {/* Row 2: J-R */}
        {ALPHABET.slice(9, 18).map((letter) => (
          <Bulb 
            key={letter} 
            letter={letter} 
            isActive={activeLetter === letter} 
          />
        ))}

        {/* Row 3: S-Z (8 letters) */}
        <div className="col-span-9 flex justify-center gap-4">
          {ALPHABET.slice(18).map((letter) => (
            <Bulb 
              key={letter} 
              letter={letter} 
              isActive={activeLetter === letter} 
            />
          ))}
        </div>
      </div>
    </div>
  );
};
