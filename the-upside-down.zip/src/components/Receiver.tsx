import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db, collection, onSnapshot, query, orderBy, limit, onAuthStateChanged, User, where } from '../firebase.ts';
import { Layout } from './Layout.tsx';
import { LightWall } from './LightWall.tsx';
import { motion, AnimatePresence } from 'motion/react';

export const Receiver: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [activeLetter, setActiveLetter] = useState<string | null>(null);
  const [decodedText, setDecodedText] = useState('');
  const [isReceiving, setIsReceiving] = useState(false);
  const [lastMessageId, setLastMessageId] = useState<string | null>(null);
  const [isScreenShaking, setIsScreenShaking] = useState(false);

  const sequenceRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (!currentUser) {
        navigate('/');
      } else {
        setUser(currentUser);
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (!user || !user.email) return;

    const q = query(
      collection(db, 'messages'), 
      where('targetEmail', '==', user.email.toLowerCase()),
      orderBy('createdAt', 'desc'), 
      limit(1)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) return;
      
      const doc = snapshot.docs[0];
      const data = doc.data();
      
      // Only process new messages
      if (doc.id !== lastMessageId) {
        setLastMessageId(doc.id);
        triggerSequence(data.text);
      }
    });

    return () => unsubscribe();
  }, [user, lastMessageId]);

  const triggerSequence = async (text: string) => {
    if (sequenceRef.current) clearTimeout(sequenceRef.current);
    
    setIsReceiving(true);
    setDecodedText('');
    setIsScreenShaking(true);
    setTimeout(() => setIsScreenShaking(false), 500);

    const letters = text.toUpperCase().split('');
    
    for (let i = 0; i < letters.length; i++) {
      const char = letters[i];
      
      if (/[A-Z]/.test(char)) {
        // Light up the bulb
        setActiveLetter(char);
        setDecodedText(prev => prev + char);
        
        await new Promise(resolve => setTimeout(resolve, 600)); // On duration
        setActiveLetter(null);
        await new Promise(resolve => setTimeout(resolve, 200)); // Gap between letters
      } else if (char === ' ') {
        // Pause for space
        setDecodedText(prev => prev + ' ');
        await new Promise(resolve => setTimeout(resolve, 800)); // Word pause
      }
    }

    // End sequence: flash all bulbs
    await new Promise(resolve => setTimeout(resolve, 500));
    // Flash effect (simplified: just show a message or something)
    setIsReceiving(false);
    setActiveLetter(null);
  };

  if (!user) return null;

  return (
    <Layout>
      <motion.div 
        animate={isScreenShaking ? { x: [-10, 10, -10, 10, 0], y: [-5, 5, -5, 5, 0] } : {}}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center gap-8 w-full max-w-5xl"
      >
        <div className="flex justify-between w-full px-4 mb-4">
          <div className="flex flex-col">
            <h2 className="text-4xl text-blood-red flicker">RECEIVER PANEL</h2>
            <div className="flex items-center gap-1 mt-1">
              <p className="text-gray-600 text-xs">SIGNAL:</p>
              <div className="flex gap-0.5">
                <div className="w-1 h-2 bg-blood-red/80" />
                <div className="w-1 h-3 bg-blood-red/80" />
                <div className="w-1 h-4 bg-blood-red/80" />
                <div className="w-1 h-5 bg-blood-red/20" />
              </div>
              <p className="text-gray-600 text-[10px] ml-2 uppercase">Tuned to {user.email}</p>
            </div>
          </div>
          <AnimatePresence>
            {isReceiving && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-2xl text-blood-red flicker font-bold"
              >
                RECEIVING SIGNAL...
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <LightWall activeLetter={activeLetter} />

        <div className="w-full mt-12 p-8 wood-panel rounded-lg shadow-2xl min-h-[150px] relative">
          <div className="absolute inset-0 crt-static pointer-events-none opacity-10" />
          <h3 className="text-xl text-gray-500 mb-4 border-b border-gray-800 pb-2">DECODED MESSAGE:</h3>
          <div 
            className="text-4xl text-white font-bold tracking-widest typewriter"
            style={{ fontFamily: 'Special Elite' }}
          >
            {decodedText}
          </div>
        </div>

        <div className="mt-8 flex justify-between w-full text-gray-600 text-sm">
          <span>RECEIVER: {user.email}</span>
          <button onClick={() => navigate('/')} className="hover:text-blood-red">RETURN TO HUB</button>
        </div>
      </motion.div>
    </Layout>
  );
};
