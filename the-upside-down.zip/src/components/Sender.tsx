import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db, collection, addDoc, serverTimestamp, onAuthStateChanged, User } from '../firebase.ts';
import { Layout } from './Layout.tsx';
import { motion } from 'motion/react';

export const Sender: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [message, setMessage] = useState('');
  const [targetEmail, setTargetEmail] = useState('');
  const [isTransmitting, setIsTransmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (!currentUser) {
        navigate('/');
      } else {
        setUser(currentUser);
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleTransmit = async () => {
    if (!message.trim() || !targetEmail.trim() || !user) return;
    
    setIsTransmitting(true);
    setError(null);
    
    try {
      await addDoc(collection(db, 'messages'), {
        text: message.toUpperCase(),
        senderId: user.uid,
        senderEmail: user.email,
        targetEmail: targetEmail.trim().toLowerCase(),
        createdAt: serverTimestamp(),
        processed: false
      });
      setMessage('');
      // Show success briefly
      setTimeout(() => setIsTransmitting(false), 2000);
    } catch (err) {
      console.error("Transmission failed:", err);
      setError("TRANSMISSION FAILED. THE VOID IS UNSTABLE.");
      setIsTransmitting(false);
    }
  };

  if (!user) return null;

  return (
    <Layout>
      <div className="flex flex-col items-center gap-8 max-w-2xl w-full p-12 wood-panel rounded-xl shadow-2xl relative">
        <div className="flex justify-between w-full items-center mb-4">
          <h2 className="text-4xl text-blood-red flicker">SENDER PANEL</h2>
          {targetEmail && (
            <div className="flex items-center gap-2 text-blood-red/50 text-xs animate-pulse">
              <div className="flex gap-0.5 mr-2">
                <div className="w-1 h-2 bg-blood-red/80" />
                <div className="w-1 h-3 bg-blood-red/80" />
                <div className="w-1 h-4 bg-blood-red/80" />
                <div className="w-1 h-5 bg-blood-red/20" />
              </div>
              BROADCASTING TO {targetEmail.toUpperCase()}
            </div>
          )}
        </div>
        
        <div className="w-full flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label className="text-gray-500 text-sm">TARGET RECEIVER EMAIL:</label>
            <input 
              type="email"
              value={targetEmail}
              onChange={(e) => setTargetEmail(e.target.value)}
              placeholder="ENTER RECEIVER'S GOOGLE EMAIL..."
              className="w-full p-4 bg-black/50 text-white text-xl font-bold rounded-lg border-2 border-red-900/30 focus:border-blood-red outline-none transition-all duration-300"
              style={{ fontFamily: 'Special Elite' }}
              disabled={isTransmitting}
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-gray-500 text-sm">YOUR MESSAGE:</label>
            <textarea 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="TYPE YOUR MESSAGE TO THE OTHER SIDE..."
              className="w-full h-48 p-6 bg-black/50 text-white text-2xl font-bold rounded-lg border-2 border-red-900/50 focus:border-blood-red outline-none resize-none placeholder:text-gray-700 transition-all duration-300"
              style={{ fontFamily: 'Special Elite' }}
              disabled={isTransmitting}
            />
          </div>
        </div>

        {error && <p className="text-blood-red text-xl flicker">{error}</p>}

        <button 
          onClick={handleTransmit}
          disabled={isTransmitting || !message.trim() || !targetEmail.trim()}
          className="w-full py-6 px-12 bg-blood-red text-white text-3xl font-bold rounded-lg hover:bg-red-800 disabled:bg-gray-800 disabled:text-gray-600 transition-all duration-300 shadow-[0_0_20px_rgba(255,34,0,0.5)] border-2 border-red-900"
          style={{ fontFamily: 'Special Elite' }}
        >
          {isTransmitting ? 'SIGNAL SENT' : 'TRANSMIT SIGNAL'}
        </button>

        <div className="mt-8 flex justify-between w-full text-gray-600 text-sm">
          <span>SENDER: {user.email}</span>
          <button onClick={() => navigate('/')} className="hover:text-blood-red">RETURN TO HUB</button>
        </div>

        {/* Wire to Receiver */}
        <div className="absolute -right-24 top-1/2 -translate-y-1/2 hidden lg:block">
          <div className="w-24 h-0.5 bg-gray-800 relative">
            {isTransmitting && (
              <motion.div 
                initial={{ left: 0 }}
                animate={{ left: '100%' }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-blood-red rounded-full shadow-[0_0_10px_#ff2200]"
              />
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};
