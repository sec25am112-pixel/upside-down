import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface BulbProps {
  letter: string;
  isActive: boolean;
  color?: string;
}

const BULB_COLORS = [
  '#ff2200', // red
  '#ff6600', // orange
  '#ffcc00', // yellow
  '#00ff44', // green
  '#0088ff', // blue
  '#cc00ff', // purple
];

export const Bulb: React.FC<BulbProps> = ({ letter, isActive, color }) => {
  const bulbColor = color || BULB_COLORS[letter.charCodeAt(0) % BULB_COLORS.length];

  return (
    <div className="flex flex-col items-center justify-center p-2">
      <div className="relative w-12 h-16">
        {/* Wire */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-4 bg-gray-800" />
        
        {/* Bulb Body */}
        <div 
          className={cn(
            "absolute top-4 left-1/2 -translate-x-1/2 w-8 h-10 rounded-full transition-all duration-300",
            isActive ? "scale-110" : "scale-100 opacity-40 grayscale-[0.5]"
          )}
          style={{
            backgroundColor: isActive ? bulbColor : '#333',
            boxShadow: isActive 
              ? `0 0 10px #fff, 0 0 20px ${bulbColor}, 0 0 40px ${bulbColor}` 
              : 'none'
          }}
        >
          {/* Inner Core */}
          <AnimatePresence>
            {isActive && (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                className="absolute inset-1 bg-white/80 rounded-full blur-[2px]"
              />
            )}
          </AnimatePresence>
        </div>
      </div>
      
      {/* Letter on Wall */}
      <span 
        className={cn(
          "mt-2 text-2xl font-bold transition-all duration-300",
          isActive ? "text-black scale-125 opacity-100" : "text-black/30 opacity-50"
        )}
        style={{
          fontFamily: 'Special Elite',
          textShadow: isActive ? '0 0 5px rgba(255,255,255,0.5)' : 'none'
        }}
      >
        {letter}
      </span>
    </div>
  );
};
