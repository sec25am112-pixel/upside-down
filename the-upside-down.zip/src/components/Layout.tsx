import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen relative overflow-hidden bg-upside-down-bg">
      {/* Background Layers */}
      <div className="absolute inset-0 wallpaper pointer-events-none" />
      <div className="absolute inset-0 vignette pointer-events-none" />
      <div className="absolute inset-0 crt-static pointer-events-none" />
      
      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-4">
        <h1 className="text-6xl md:text-8xl text-blood-red title-glow mb-12 tracking-widest flicker">
          THE UPSIDE DOWN
        </h1>
        {children}
      </div>
    </div>
  );
};
